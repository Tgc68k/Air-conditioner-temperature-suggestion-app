from django.db import models
from django.utils import timezone
# Create your models here.
class Data(models.Model):
    temp1101 = models.FloatField(default = 0)
    temp2101 = models.FloatField(default = 0)
    time = models.DateTimeField(default=timezone.now)


class P_D(models.Model):
    temp = models.FloatField(default = 0)
    hum = models.FloatField(default = 0)
    time = models.DateTimeField(default=timezone.now)
    hukai = models.FloatField(default = 0)
    
class Data3105(models.Model):
    temp = models.FloatField(default = 0)
    hum = models.FloatField(default = 0)
    time = models.DateTimeField(default=timezone.now)
    airpressure = models.FloatField(default = 0)
    illuminance = models.FloatField(default = 0)
