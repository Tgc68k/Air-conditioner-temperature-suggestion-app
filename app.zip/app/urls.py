from django.urls import path

from . import views

urlpatterns = [
    path('to_create', views.to_create, name='to_create'),
    path('to_pri', views.to_pri, name='to_pri'),
    path('', views.index, name='app'),
    path('pri', views.pri, name='pri'),
    path('create',views.create,name="create"),
    path('stop',views.stop,name = "stop"),
    # path('main',views.main,name = "main")
#    path('<str:room_name>/', views.room, name='room'),
]
#ok
