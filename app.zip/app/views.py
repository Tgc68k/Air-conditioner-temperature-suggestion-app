from django.shortcuts import render
from .models import Data, P_D ,Data3105
import time
def index(request):
    return render(request, 'app/s_main.html', {})

def create(request):

    if request.method=="POST":
        data = Data3105.objects.create(temp = request.POST['temp3105'],
        illuminance = request.POST['illuminance3105'],
        hum = request.POST['humidity3105'],
        airpressure = request.POST['airpressure3105']
    )
        data.save()
    return render(request,'app/index.html',{})

def stop(request):

    return render(request,'app/a.html',{})

def pri(request):
    if request.method=="POST":
        p_d = P_D.objects.create(temp = request.POST['temp'],
        hum = request.POST['hum'],
        # date = request.POST['date'],
        hukai = request.POST['hukai']
    )
        p_d.save()
        # data add
    return render(request,'app/pri.html',{})




def to_create(request):

    return render(request,'app/index.html',{})
def to_pri(request):

    return render(request,'app/pri.html',{})

# def main(request):
#     return render(request,'app/main.html',{})
