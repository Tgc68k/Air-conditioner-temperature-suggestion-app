
var intervalID;
function record_ini(){
    document.getElementById("push").disabled = "true"
    // document.forms.test_form1.temp1101.value = getRoomStatus(id,pass,"1101");//
    // document.forms.test_form1.temp2101.value = getRoomStatus(id,pass,"2101");
    // setTimeout(record,5000);

    intervalID = setInterval(record,10000);
}
function record(){
    // if(cnt == 0){
    var id = "s1F101804007";//write your id
    var pass = "taka1101";//write your pass 
    document.getElementById("push").disabled = false
    console.log(getRoomStatus(id,pass,"3105"));
     // document.forms.test_form1.temp3105.value = result["temperature"];
    // document.forms.test_form1.humidity3105.value = result["humidity"];
    // document.forms.test_form1.airpressure3105.value = result["airpressure"];
    // document.forms.test_form1.illuminance3105.value = result["illuminance"];
    console.log(document.forms.test_form1.illuminance3105.value )
    if(document.forms.test_form1.airpressure3105.value != 0.0)
    {document.getElementById("push").click()}

    // else {
    //     clearInterval(intervalID);
    // }
    // document.getElementById("push2").click();
}
