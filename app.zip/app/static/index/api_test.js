var BASE_URL = "https://2018-eduiot.iniad.org/api/v1";

function sleep(waitMsec) {
  var startMsec = new Date();
 
  // 指定ミリ秒間だけループさせる（CPUは常にビジー状態）
  while (new Date() - startMsec < waitMsec);
}
function displayRoomStatus(result) {
  
  if (result.status == 'success') {
    if(result["roomnum"]=="3105"){
    document.forms.test_form1.temp3105.value = result["temperature"];
    document.forms.test_form1.humidity3105.value = result["humidity"];
    document.forms.test_form1.airpressure3105.value = result["airpressure"];
    document.forms.test_form1.illuminance3105.value = result["illuminance"];
    }
    
    // document.getElementById("push").click()
  } else {
    console.log(result);//保存用
  }
}

function getRoomStatus(id,pass,num) {
  var userid = id;
  var userpw = pass;
  var roomNum =num;
  var url =BASE_URL+'/sensors/'+roomNum;
  // console.log(callRoomStatusAPI(url, 'GET', userid, userpw, num, displayRoomStatus))
  callRoomStatusAPI(url, 'GET', userid, userpw, num, displayRoomStatus );
}

var BASE_URL = "https://2018-eduiot.iniad.org/api/v1";

// function displayRoomStatus(result) {
//   var monitoringResults = document.getElementById("monitoring-result");
//   var temperature = document.getElementById("room-temperature");
//   var humidity = document.getElementById("room-humidity");
//   var airpressure = document.getElementById("room-airpressure");
//   var illuminance = document.getElementById("room-illuminance");
//   monitoringResults.textContent = result["status"];
//   if (result.status == 'success') {
//     temperature.textContent = result["temperature"];
//     humidity.textContent = result["humidity"];
//     airpressure.textContent = result["airpressure"];
//     illuminance.textContent = result["illuminance"];
//   } else {
//     none
//   }
// }

// function getRoomStatus() {
//   var userid=document.getElementById("iniad-id").value;
//   var userpw =document.getElementById("iniad-pw").value;
//   var roomNum =document.getElementById("room-number").value;
//   var url =BASE_URL+'/sensors/'+roomNum;
//   callRoomStatusAPI(url, 'GET', userid, userpw, displayRoomStatus);
// }
