// var cnt = 0;



// function startInterval(){
//     var id = "********";//write your id
//     var pass = "*******";//write your pass 
//     document.forms.test_form1.temp1101.value = getRoomStatus(id,pass,"1101");//
//     document.forms.test_form1.temp2101.value = getRoomStatus(id,pass,"2101");
//     // setTimeout(record,5000);
//     intervalID = setInterval(record,5000);
// }

function record1(callback){
  $.ajax({
      url: 'http://59.138.46.197:58082/data', // cakephpで用意したAPIのURL
      type: "GET",
      dataType: "json",
      success : function(results){
        
      callback({
        status : 'success',
        description : 'Succeeded getting room status',
        date : results.date,
        temp : results.temp,
        hum : results.hum,
        fukai : results.fukai
        
      });

      }  
    });  
}

function startPrivate(){//個人用
  var start = record1(show);
  console.log(start);
   
}
function show(result){
  if (result.status == 'success') {
    document.forms.test_form2.temp.value = result.date;
    document.forms.test_form2.hum.value = result.temp;
    document.forms.test_form2.hukai.value = result.hum;
    document.forms.test_form2.date.value = result.hukai;

  } else {
    return 0.0;
  }
}

// function stop(){
//     cnt = 1;
// }

// function altRan2() {
// 	var r = (Math.random() * 6) +1.0; //乱数の発生
// 	return r; //値の出力
// }
// window.onload = function(){
//     document.getElementById("push").click();
//     }
    