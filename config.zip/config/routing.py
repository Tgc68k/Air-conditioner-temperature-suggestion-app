from chabbels.routing import ProtocolTypeRouter
application = ProtocolTypeRouter({
    # (http->django views is added by default)
})
