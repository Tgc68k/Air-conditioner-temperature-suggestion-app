from django.urls import path

from . import views

urlpatterns = [
    # path
    path("",views.index, name = 'index'),
    path('mainpage.html', views.index, name='index'),
    path('graph', views.graph, name='graph'),
    path('visual.html', views.visual, name='visual'),
    path('save.html', views.save, name='save'),
#    path('<str:room_name>/', views.room, name='room'),
]
