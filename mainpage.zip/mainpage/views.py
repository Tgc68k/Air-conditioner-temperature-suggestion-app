from django.shortcuts import render
from mainpage.static.mainpage.graph import database

def index(request):
    data = {
        'data_temp' : database.app_data_temp(3105),
    }
    return render(request, 'mainpage/mainpage.html', data)
def graph(request):
    return render(request,'mainpage/new.html',{})
def save(request):
    return render(request,'mainpage/save.html',{})

def visual(request):
    data = {
        'data_list' : database.app_data(3105),
        'data_temp' : database.app_data_temp(3105),
        'data_text' : database.data_text(database.app_data_temp(3105))
    }
    return render(request,'mainpage/visual.html', data)

