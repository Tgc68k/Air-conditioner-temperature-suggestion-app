import sqlite3
from django.db import models
import re
from datetime import datetime, timedelta
# from django.utils import timezone
# from django.shortcuts import render

def kwh_calc(hour_list, day_list, thr_list):
  hour_kwh = 0
  day_kwh = 0
  thr_kwh = 0
  if len(hour_list) > 1:
    hour_time = datetime.strptime(hour_list[-1], "%Y-%m-%d %H:%M:%S") - datetime.strptime(hour_list[0], "%Y-%m-%d %H:%M:%S")
    hour_time = hour_time.total_seconds()
    hour_kwh = hour_time.total_seconds * 560 / 60 / 60
  if len(day_list) > 1:
    day_time = datetime.strptime(day_list[-1], "%Y-%m-%d %H:%M:%S") - datetime.strptime(day_list[0], "%Y-%m-%d %H:%M:%S")
    day_time = day_time.total_seconds()
    day_kwh = day_time.total_seconds * 560 / 60 / 60
  if len(thr_list) > 1:
    thr_time = datetime.strptime(thr_list[-1], "%Y-%m-%d %H:%M:%S") - datetime.strptime(thr_list[0], "%Y-%m-%d %H:%M:%S")
    thr_time = thr_time.total_seconds()
    thr_kwh = thr_time * 560 / 60 / 60
  kwh = [int(thr_kwh), int(day_kwh), int(hour_kwh)]
  return kwh

def app_data(num):
  conn = sqlite3.connect('db.sqlite3')
  c = conn.cursor()
  a = 'SELECT time FROM app_data'
  z = str(datetime.now() - timedelta(days=3))
  b = " where time >= '"
  string = a + str(num) + b + z + "'"
  string2 = "select name from sqlite_master where type='table'"
  print(string) 
  c.execute(string)
  result = c.fetchall()
  print(result)
  c.close()
  conn.close()

  now_time = re.sub(r'\..+$', '', str(datetime.now()))
  hour_list = []
  day_list = []
  thr_list = []
  for i in result:
    for date in i:
      date = re.sub(r'\..+$', '', str(date))
      time = datetime.strptime(now_time, "%Y-%m-%d %H:%M:%S") - datetime.strptime(date, "%Y-%m-%d %H:%M:%S")
      if time <= timedelta(hours=1):
        hour_list.append(date)
      elif time <= timedelta(days=1):
        day_list.append(date)
      else:
        thr_list.append(date)
  return kwh_calc(hour_list, day_list, thr_list)

def app_data_temp(num):
  now_time = datetime.now()
  now_time = re.sub(r'\..+$', '', str(now_time))
  print(now_time)
  conn = sqlite3.connect('db.sqlite3')
  c = conn.cursor()
  a = 'SELECT temp, time FROM app_data'
  b = " ORDER BY id DESC LIMIT 1"
  string = a + str(num) + b + ""
  print(string)
  c.execute(string)
  result = c.fetchall()
  print(result)
  c.close()
  conn.close()

  temp = 0
  for data in result:
    now_time = re.sub(r'\..+$', '', str(datetime.now()))
    time_data = re.sub(r'\..+$', '', str(data[1]))
    time_calc = datetime.strptime(now_time, "%Y-%m-%d %H:%M:%S") - datetime.strptime(time_data, "%Y-%m-%d %H:%M:%S")
    if time_calc.total_seconds() <= 600: 
      temp = data
      print(time_calc)
      print(temp)
      return temp
    else:
      temp = ''
      return temp

def data_text(temp):
  if temp == '':
    text = 'エアコンの設定温度が取得されていません。'
  elif temp <= 26:
    text = '現在のおすすめの設定温度は28度です。'
  elif temp <= 25:
    text = '現在のおすすめの設定温度は27度です。'
  elif temp >= 30:
    text = '現在のおすすめの設定温度は28度です。'
  print(text)
  return text
