var city = "Tokyo";


$(document).ready(function() {
    //個人のopenweathermapのID
  var url = "http://api.openweathermap.org/data/2.5/weather?units=metric&q=" + city + "&appid=c0e464db5de3332c579389b5f70c3a4d";
  $.getJSON(url, function(data) {

    cityname = data.name;
    dto = new Date();
    dto.setTime(Number(data.dt)*1000);
    weather = data.weather[0].main;
    temp = Number(data.main.temp);
    temp = parseInt(temp, 10)
    temp_max = Number(data.main.temp_max);
    temp_min = Number(data.main.temp_min);
    humidity = Number(data.main.humidity);
    //不快指数
    fukai = (0.81*temp) + ((0.01*humidity) * ((0.99*temp) - 14.3)) + 46.3
    fukai = parseInt(fukai, 10)
//ページの中に表示するためのhtml文字列を作成する。
    var htmltext = "";


    var htmltext1 = "";
    htmltext1 += "<div>"
    htmltext1 += "[ 外気温: " + temp +"℃ ]";
    //温度の変化で画像を変化させる。
    if (temp<-7){
      document.getElementById("image").src="/static/home_pic/temp-10.png";
  }
  else if (-7<=temp && temp<-2){
      document.getElementById("image").src="/static/home_pic/temp-5.png";
  }
  else if (-2<=temp && temp<3){
    document.getElementById("image").src="/static/home_pic/temp0.png";
  }
  else if (3<=temp && temp<8){
    document.getElementById("image").src="/static/home_pic/temp5.png";
  }
  else if (8<=temp && temp<13){
    document.getElementById("image").src="/static/home_pic/temp10.png";
  }
  else if (13<=temp && temp<18){
    document.getElementById("image").src="/static/home_pic/temp15.png";
  }
  else if (18<=temp && temp<23){
    document.getElementById("image").src="/static/home_pic/temp20.png";
  }
  else if (23<=temp && temp<28){
    document.getElementById("image").src="/static/home_pic/temp25.png";
  }
  else if (28<=temp && temp<33){
    document.getElementById("image").src="/static/home_pic/temp30.png";
  }
  else if (33<=temp && temp<38){
    document.getElementById("image").src="/static/home_pic/temp35.png";
  }
  else if (38<=temp){
    document.getElementById("image").src="/static/home_pic/temp40.png";
  }

  var htmltext2 = "";
  htmltext2 += "<div>"
  htmltext2 += "[ 湿度: " + humidity + "% ]";
  //湿度の変化で画像を変化させる。
  if (humidity<5){
      document.getElementById("image2").src = "/static/home_pic/water0.png";
  }
  else if (5 <= humidity && humidity < 15){
      document.getElementById("image2").src = "/static/home_pic/water10.png";
  }
  else if (15 <= humidity && humidity < 25){
      document.getElementById("image2").src = "/static/home_pic/water20.png";
  }
  else if (25 <= humidity && humidity < 35){
    document.getElementById("image2").src = "/static/home_pic/water30.png";
  }
  else if (35 <= humidity && humidity < 45){
    document.getElementById("image2").src = "/static/home_pic/water40.png";
  }
  else if (45 <= humidity && humidity < 55){
    document.getElementById("image2").src = "/static/home_pic/water50.png";
  }
  else if (55 <= humidity && humidity < 65){
    document.getElementById("image2").src = "/static/home_pic/water60.png";
  }
  else if (65 <= humidity && humidity < 75){
    document.getElementById("image2").src = "/static/home_pic/water70.png";
  }
  else if (75 <= humidity && humidity < 85){
    document.getElementById("image2").src = "/static/home_pic/water80.png";
  }
  else if (85 <= humidity && humidity < 95){
    document.getElementById("image2").src = "/static/home_pic/water90.png";
  }
  else if (95 <= humidity && humidity <= 100){
    document.getElementById("image2").src = "/static/home_pic/water100.png";
  }


  var htmltext3 = "";
  htmltext3 += "<div>"
  htmltext3 += "[ 不快指数: " + fukai + " ]";
  //不快指数の計算から画像を変化させる。
  if (fukai<55){
      document.getElementById("image3").src = "/static/home_pic/fukai50.png";
  }
  else if(55 <= fukai && fukai < 60){
      document.getElementById("image3").src = "/static/home_pic/fukai55.png";
  }
  else if(60 <= fukai && fukai < 65){
      document.getElementById("image3").src = "/static/home_pic/fukai60.png";
  }
  else if(65 <= fukai && fukai < 70){
    document.getElementById("image3").src = "/static/home_pic/fukai65.png";
  }
  else if(70 <= fukai && fukai < 75){
    document.getElementById("image3").src = "/static/home_pic/fukai70.png";
  }
  else if(75 <= fukai && fukai < 80){
    document.getElementById("image3").src = "/static/home_pic/fukai75.png";
  }
  else if(80 <= fukai && fukai < 85){
    document.getElementById("image3").src = "/static/home_pic/fukai80.png";
  }
  else if(85 <= fukai){
    document.getElementById("image3").src = "/static/home_pic/fukai85.png";
  }

    //ページの中のid=weatherinfoのタグに、作成したhtml文字列を埋め込む。
    var domwinfo = document.getElementById("scoredata");
    domwinfo.innerHTML = htmltext;


    var downinfo1 = document.getElementById("exam1");
    downinfo1.innerHTML = htmltext1;

    var downinfo2 = document.getElementById("exam2");
    downinfo2.innerHTML = htmltext2;

    var downinfo3 = document.getElementById("exam3");
    downinfo3.innerHTML = htmltext3;

});
});
