var dt;
var date_diff;
var flag = 0;
function visual_button() {
    //日付オブジェクトを作成する
    a = document.getElementById("status");
    a.textContent = "ON";
    elm1 = document.getElementById("on");
    elm1.disabled = "true";
    elm2 = document.getElementById("of");
    elm2.disabled = false;
    elm3 = document.getElementById("hot");
    elm3.disabled = "true";
    elm4 = document.getElementById("cool");
    elm4.disabled = "true";
    elm5 = document.getElementById("sub");
    elm5.disabled = "true";
    if(flag == 0){
    dt = new Date();
    //「年」を取得する

    var YYYY = dt.getFullYear();
    //「月」を取得する
    var MM = dt.getMonth() + 1;
    //「日」を取得する
    var DD = dt.getDate();
    var hh = dt.getHours();
    var mm = dt.getMinutes();
    var ss = dt.getSeconds();
    //段落タグ("date011")の中身を置き換える
    var time_visual = document.getElementById("time");
    time_visual.innerHTML = YYYY + "/" + MM + "/" + DD + " " + hh + ":" + mm + ":" + ss;
    // if(flag==0){;}
    // flag = 1;
    console.log(flag);
    flag=1;
    push();
    return dt;
    }

};

function visual_button_minus() {
  b = document.getElementById("status");
  b.textContent = "OFF";
    var date0 = dt;
    elm1 = document.getElementById("on");
    elm1.disabled = false;
    elm2 = document.getElementById("of");
    elm2.disabled = "true";
    elm3 = document.getElementById("hot");
    elm3.disabled = false;
    elm4 = document.getElementById("cool");
    elm4.disabled = false;
    elm5 = document.getElementById("sub");
    elm5.disabled = false;
    //日付オブジェクト（指定日B）を作成する
    var date1 = new Date();
    console.log("date0時間：", date0);
    console.log("date1時間：", date1);
    //指定日Aと指定日Bの差分（ミリ秒）を計算する
    var date_diff = Math.floor((date1 - date0) / 1000);
    var pelem022 = document.getElementById("minus");
    pelem022.innerHTML = date_diff + "秒";
    console.log("経過時間：", date_diff);
    // return date_diff;
    push();
    flag = 0;
};

function record1(callback){
    $.ajax({
        url: 'http://59.138.46.197:58082/bigdata', // cakephpで用意したAPIのURL
        type: "GET",
        dataType: "json",
        success : function(results){

        callback({
          status : 'success',
          description : 'Succeeded getting room status',
          date : results.date,
          temp : results.temp,
          hum : results.hum,
          fukai : results.fukai

        });

        }
      });
  }
  function record2(callback){
    $.ajax({
        url: 'http://59.138.46.197:58082/data', // cakephpで用意したAPIのURL
        type: "GET",
        dataType: "json",
        success : function(results){

        callback({
          status : 'success',
          description : 'Succeeded getting room status',
          date : results.date,
          temp : results.temp,
          hum : results.hum,
          fukai : results.fukai

        });

        }
      });
  }
  function push(){
    // console.log(document.getElementById("status").textContent);
    // console.log(document.getElementById("types").textContent);
    var data1 = document.getElementById("status").textContent;
    var data2 = document.getElementById("types").textContent;
    var data3 = document.getElementById("settemp").textContent;
    // var data3 = '{"switch":"' + data1 + '","mode":"' + data2 + '","preset_temp":"' + data2 + '"}'
    //console.log(data3);
    $.ajax({

        url: 'http://59.138.46.197:58082/aircon', // cakephpで用意したAPIのURL
        type: "POST",
        dataType: "json",
        data : '{"switch":"' + data1 + '","mode":"' + data2 + '","preset_temp":"' + data3 + '"}',
      //   switch : data1,
      //   preset_temp : data2
      // },
        success : function(data) {
          if(data){console.log(data.status);}//データ関連をいじる
            alert('OK');
      },
        error : function(data) {
          alert('通信エラー');
        }
    });
//       }).done(function(data)
//         alert("ok");
// }).fail(function(XMLHttpRequest, textStatus, errorThrown) {
//   alert('error!!!');
//   　　console.log("XMLHttpRequest : " + XMLHttpRequest.status);
//   　　console.log("textStatus     : " + textStatus);
//   　　console.log("errorThrown    : " + errorThrown.message);
// });
      return false;
  }


  function cool(){
    elm1 = document.getElementById("sub");
    elm1.disabled = false;
    elm3 = document.getElementById("hot");
    elm3.disabled = false;
    // elm = document.getElementById("on");
    // elm.disabled = false;
    elm2 = document.getElementById("cool");
    elm2.disabled = "true";
    b = document.getElementById("types");
    b.textContent = "COOL";
    a = document.getElementById("graph");
    a.style.backgroundColor = "rgb(53, 236, 236)";}

  function hot(){
    elm1 = document.getElementById("sub");
    elm1.disabled = false;
    elm3 = document.getElementById("cool");
    elm3.disabled = false;
    // elm = document.getElementById("on");
    // elm.disabled = false;
    
    b = document.getElementById("types");
    b.textContent = "HOT";
    elm2 = document.getElementById("hot");
    elm2.disabled = "true";
    a = document.getElementById("graph");
    a.style.backgroundColor = "rgb(255, 60, 0)";}
  function set(){
    elm1 = document.getElementById("on");
    elm1.disabled = false;
    // elm = document.getElementById("of");
    // elm.disabled = false;
    a = document.getElementById("settemp");
    b = document.getElementById("mode").value;
    console.log(b);
    a.textContent = b;
  }

  function startPrivate(){//個人用
      record1(show);
  }



  function show2(result){//x=result.temp;
    x = result.temp;
  }

  $(function show2(result) {
    $(".overlay-btn-sample").click(function() {
          $(".overlayall-sample").fadeIn();/*Display slowly*/
          document.getElementById("change").innerText = ('');
});
    $(".overlayall-sample").click(function() {
          $(".overlayall-sample").fadeOut();/*Disappear slowly*/
});
});


  function show(result){
    if (result.status == 'success') {
      $("#wrap").val(result.date);
      $("#wrap1").val(result.temp);
      $("#wrap2").val(result.hum);
      $("#wrap3").val(result.fukai);
       $("#out1").text($("#wrap1").val());
       var canvas = document.getElementById('stage');
       var chart = new Chart(canvas, {
         type: 'line',  //グラフの種類
         data:{labels:result.date,
      datasets: [
        {
          label: '気温(度）',
          data: result.temp,
          borderColor: "rgba(255,0,0,1)",
          backgroundColor: "rgba(0,0,0,0)"
        },
        {
          label: '湿度(%）',
          data: result.hum,
          borderColor: "rgba(0,0,255,1)",
          backgroundColor: "rgba(0,0,0,0)"
        }],},
        options: {
            title: {
              display: true,
              text: '気温,湿度'
            },
            scales: {
              yAxes: [{
                ticks: {
                  suggestedMax: 40,
                  suggestedMin: 0,
                  stepSize: 10,
                  callback: function(value, index, values){
                    return  value
                  }
                }
              }]
            },
        }


       });

    } else {
      return 0.0;
    }
  }
